drop table ang_as;
drop table dept_as;
