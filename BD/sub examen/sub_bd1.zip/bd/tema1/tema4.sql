INSERT INTO SERIE_ANCS (CodSerie,DenSerie,NrGrupe,An)
VALUES (1,'Seria nr 1',4,1);
INSERT INTO SERIE_ANCS (CodSerie,DenSerie,NrGrupe,An)
VALUES (2,'Seria nr 2',3,1);
INSERT INTO SERIE_ANCS (CodSerie,DenSerie,NrGrupe,An)
VALUES (3,'Seria nr 3',4,2);
INSERT INTO SERIE_ANCS (CodSerie,DenSerie,NrGrupe,An)
VALUES (4,'Seria finala',3,2);

INSERT INTO GRUPA_ANCS (CodGrupa,DenGrupa,NrStudenti,CodSerie)
VALUES (1,'Grupa nr 1',10,1);
INSERT INTO GRUPA_ANCS (CodGrupa,DenGrupa,NrStudenti,CodSerie)
VALUES (2,'Grupa nr 2',11,2);
INSERT INTO GRUPA_ANCS (CodGrupa,DenGrupa,NrStudenti,CodSerie)
VALUES (3,'Grupa nr 3',12,3);
INSERT INTO GRUPA_ANCS (CodGrupa,DenGrupa,NrStudenti,CodSerie)
VALUES (4,'Grupa nr 4',13,4);
INSERT INTO GRUPA_ANCS (CodGrupa,DenGrupa,NrStudenti,CodSerie)
VALUES (5,'Grupa nr 5',14,1);
INSERT INTO GRUPA_ANCS (CodGrupa,DenGrupa,NrStudenti,CodSerie)
VALUES (6,'Grupa finala',15,2);
