INSERT INTO SERIE_ANCS (CodSerie,DenSerie,NrGrupe,An)
VALUES (1,'Seria nr 5',3,3);

INSERT INTO GRUPA_ANCS (CodGrupa,DenGrupa,NrStudenti,CodSerie)
VALUES (6,'Grupa nr 7',16,5);
