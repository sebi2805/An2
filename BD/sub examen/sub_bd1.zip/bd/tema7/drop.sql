drop table studenti_as;
drop table grupa_as;