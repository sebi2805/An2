drop table produse_interzise_cd;
drop table produse_cd;
drop table clase_produs_cd;
