select * from directie_as;
select * from departament_as;
select * from angajati_as;