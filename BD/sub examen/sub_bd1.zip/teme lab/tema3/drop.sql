drop table angajati_as;
drop table departament_as;
drop table directie_as;
