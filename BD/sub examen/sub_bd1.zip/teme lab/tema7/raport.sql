set echo off 	set pagesize 20 	set feedback off 	set linesize 82 
