select * from angajati_as where salariu>=&minVar and salariu<=&maxVar;
select * from angajati_as where salariu>=&&min and salariu<=&&max;    