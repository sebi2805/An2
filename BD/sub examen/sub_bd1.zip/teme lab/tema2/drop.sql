drop table angajati_as;
drop table departament_as;
 