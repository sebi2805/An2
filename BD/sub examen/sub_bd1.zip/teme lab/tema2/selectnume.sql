select * from angajati_as where nume='&NumeVar';
select * from angajati_as where nume='&&Nume';